# This data has been replaced

These consensus sequences were originally used as reference sequences in bwa-mem.

They were made by taking the consensus of the phylip alignments originally provided by Alan Lemmon.

ConsensusSeqs_noAmbi.fasta was the concatenated consensus sequences with ambiguous bases removed (ambiguous bases could not be used in bwa-mem reference sequences). ConsensusSeqs_noAmbi.fasta was the actual file used to build the bwa-mem index.

On 1/5/2018 I discovered that Alan did not include loci among the phylip alignments that were present in his original fasta files. These loci were:

- L137
- L157
- L170
- L171
- L172
- L203
- L204
- L212
- L225
- L252
- L311
- L326
- L340
- L413

I rebuilt the consensus sequences using Alan's fasta files instead.
